
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';

if (isset($_POST["enviar"])) {
  $mensagem = $_POST["mensagem"];
  // $from = $_POST["email"];

  $mail = new PHPMailer;
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'feedbacktestepit@gmail.com';
  $mail->Password = 'ijekxnqxprkjeauv';
  $mail->SMTPSecure = 'tls';
  $mail->Port = 587;
  $mail->addAddress('grupo7pit@gmail.com', 'Teste');
  $mail->Subject = 'FeedBack';
  $mail->Body = $mensagem;

  if ($mail->send()) {
    echo 'E-mail enviado com sucesso!';
  } else {
    echo 'Erro ao enviar o e-mail: ' . $mail->ErrorInfo;
  }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - Atendimento ao Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
        }

        h1 {
            margin: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .faq-item {
            margin-bottom: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
        }

        .faq-question {
            font-weight: bold;
        }

        .faq-answer {
            margin-top: 5px;
        }

        /* Estilos para o formulário */
        .complaint-form {
            margin-top: 30px;
            text-align: center; /* Centralizar os botões */
        }

        .complaint-text {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            resize: none; /* Removendo a opção de redimensionar */
        }

        /* Estilos para os botões */
        .complaint-button-container {
            display: flex; /* Exibir os botões em uma linha */
            justify-content: center; /* Centralizar horizontalmente */
            gap: 10px; /* Espaçamento entre os botões */
        }

        .complaint-button {
            flex: 1; /* Distribuir espaço igualmente entre os botões */
            background-color: #666; /* Cinza */
            color: #000; /* Preto */
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .complaint-button.back-button {
            order: 1; /* Colocar o botão "Voltar" na frente */
        }

        /* Estilos para as caixas de texto de nome e email */
        .complaint-input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>FAQ - Atendimento ao Cliente</h1>
    </header>
    <div class="container">
        <div class="faq-item">
            <div class="faq-question">1. Como faço para entrar em contato com o suporte?</div>
            <div class="faq-answer">Você pode entrar em contato conosco pelo telefone ou pelo email de suporte (31)99853-2816.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">2. Quais são os horários de atendimento?</div>
            <div class="faq-answer">Nosso suporte está disponível de segunda a sexta-feira, das 9h às 18h.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">3. Posso cancelar minha assinatura a qualquer momento?</div>
            <div class="faq-answer">Sim, você pode cancelar sua assinatura a qualquer momento sem nenhum custo adicional.</div>
        </div>
       

        <!-- Formulário de reclamação -->
        <div class="complaint-form">
            <h2>Envie sua reclamação</h2>
            <form class="form" method="POST">

<div class="form-group">
  <label for="mensagem">Nos conte suas sugestões, avisos ou reclamações</label>
                  <!-- Caixa de texto para o nome -->
                  <input class="complaint-input" type="text" name="nome" placeholder="Nome" required><br>
                <!-- Caixa de texto para o email -->
                <input class="complaint-input" type="email" name="email" placeholder="Email" required><br>
  <textarea id="textarea" rows="10" cols="50" required="" name="mensagem"></textarea>
  
</div>

<input class="form-submit-btn" type="submit" name="enviar" value="Enviar" />

</form>
        </div>
    </div>
</body>
</html>
